/* =============================================
   HANNAH LABADORF — GREENVILLE REALTOR
   JavaScript
   ============================================= */

// ---- NAV SCROLL ----
const nav = document.getElementById('nav');
window.addEventListener('scroll', () => {
  nav.classList.toggle('scrolled', window.scrollY > 40);
});

// ---- MOBILE MENU ----
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');

hamburger.addEventListener('click', () => {
  mobileMenu.classList.toggle('open');
});

function closeMobile() {
  mobileMenu.classList.remove('open');
}

// Close mobile menu on outside click
document.addEventListener('click', (e) => {
  if (!hamburger.contains(e.target) && !mobileMenu.contains(e.target)) {
    closeMobile();
  }
});

// ---- FAQ ACCORDION ----
document.querySelectorAll('.faq__q').forEach(btn => {
  btn.addEventListener('click', () => {
    const answer = btn.nextElementSibling;
    const isOpen = btn.getAttribute('aria-expanded') === 'true';

    // Close all
    document.querySelectorAll('.faq__q').forEach(b => {
      b.setAttribute('aria-expanded', 'false');
      b.nextElementSibling.classList.remove('open');
    });

    // Open this one if it was closed
    if (!isOpen) {
      btn.setAttribute('aria-expanded', 'true');
      answer.classList.add('open');
    }
  });
});

// ---- CONTACT FORM ----
const form = document.getElementById('contactForm');
const successMsg = document.getElementById('formSuccess');
const errorMsg = document.getElementById('formError');

if (form) {
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    successMsg.hidden = true;
    errorMsg.hidden = true;

    const submitBtn = form.querySelector('[type="submit"]');
    submitBtn.textContent = 'Sending…';
    submitBtn.disabled = true;

    const data = Object.fromEntries(new FormData(form).entries());

    try {
      // Replace this with your form backend endpoint (e.g. Netlify Forms, Formspree, EmailJS)
      // For Formspree: replace YOUR_FORM_ID below and add method="POST" action="https://formspree.io/f/YOUR_FORM_ID"
      // For Netlify Forms: add data-netlify="true" to the <form> element and remove this JS submit handler

      // Demo: simulate success after 1s
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Uncomment and configure for real form submission:
      // const response = await fetch('https://formspree.io/f/YOUR_FORM_ID', {
      //   method: 'POST',
      //   headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      //   body: JSON.stringify(data)
      // });
      // if (!response.ok) throw new Error('Network response was not ok');

      form.reset();
      successMsg.hidden = false;
      successMsg.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } catch (err) {
      errorMsg.hidden = false;
    } finally {
      submitBtn.textContent = 'Send my details';
      submitBtn.disabled = false;
    }
  });
}

// ---- FADE IN ON SCROLL ----
const fadeEls = document.querySelectorAll(
  '.hero__content, .service-card, .how-card, .about__content, .about__image-wrap, .gallery__item, .faq__item, .why .container > *, .contact__left, .contact__right, .banner__inner > *'
);

fadeEls.forEach(el => el.classList.add('fade-in'));

const observer = new IntersectionObserver(
  (entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.1, rootMargin: '0px 0px -40px 0px' }
);

fadeEls.forEach(el => observer.observe(el));

// Stagger service cards and gallery items
document.querySelectorAll('.service-card, .gallery__item, .how-card').forEach((el, i) => {
  el.style.transitionDelay = `${i * 0.08}s`;
});
