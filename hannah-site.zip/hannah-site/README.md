# Hannah Labadorf — Greenville Realtor Website

Personal website for Hannah Labadorf, licensed Realtor with Keller Williams in Greenville, SC.

## File Structure

```
hannah-site/
├── index.html        # Main HTML (single page)
├── css/
│   └── style.css     # All styles
├── js/
│   └── main.js       # Nav, FAQ accordion, contact form, scroll animations
├── images/           # Add your local image assets here
└── README.md
```

## Deploying to GitHub Pages

1. Push this repo to GitHub
2. Go to **Settings → Pages**
3. Set source to `main` branch, `/ (root)` folder
4. Your site will be live at `https://yourusername.github.io/repo-name`

## Setting Up the Contact Form

The form currently simulates a successful submission. To wire it up for real, choose one option:

### Option A — Formspree (easiest, free tier available)
1. Sign up at [formspree.io](https://formspree.io)
2. Create a new form and copy your form ID
3. In `js/main.js`, uncomment the `fetch` block and replace `YOUR_FORM_ID`
4. Remove the `await new Promise(...)` demo line

### Option B — Netlify Forms (free, if hosting on Netlify)
1. Add `data-netlify="true"` to the `<form>` tag in `index.html`
2. Remove the JS submit handler in `main.js` (Netlify handles it automatically)

### Option C — EmailJS (no backend needed)
1. Sign up at [emailjs.com](https://emailjs.com)
2. Follow their browser SDK setup and call `emailjs.send()` in the form handler

## Fonts

Uses Google Fonts:
- **Cormorant Garamond** — headings and display text
- **DM Sans** — body copy

Loaded via `<link>` tag in `index.html`. No npm or build step needed.

## Newsletter

The "Send me the homework" links point to:
`https://hannah-labadorf-realtor.kit.com/e551679830`

Update this URL in `index.html` if your Kit (ConvertKit) form URL changes.

## Customizing Colors

All colors are CSS custom properties at the top of `style.css`:

```css
:root {
  --cream: #f7f3ee;
  --terracotta: #c4714a;   /* primary accent / CTA buttons */
  --sage: #8a9e84;         /* secondary accent / labels */
  --charcoal: #2a2520;     /* dark sections */
  ...
}
```

Change `--terracotta` to adjust the primary brand color throughout the site.

## Images

Gallery images currently load from the CDN used by the original site builder. To host them yourself:

1. Download each image
2. Place them in the `/images/` folder
3. Update the `src` attributes in `index.html` to point to `images/filename.png`

## License

Personal website — all content copyright Hannah Labadorf.
